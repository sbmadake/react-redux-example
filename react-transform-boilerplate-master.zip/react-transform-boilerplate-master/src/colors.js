export const NICE = 'pink';
export const SUPER_NICE = 'darkred';